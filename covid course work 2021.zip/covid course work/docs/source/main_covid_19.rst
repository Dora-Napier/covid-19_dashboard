main\_covid\_19 package
=======================

Submodules
----------

main\_covid\_19.covid\_data\_handler module
-------------------------------------------

.. automodule:: main_covid_19.covid_data_handler
   :members:
   :undoc-members:
   :show-inheritance:

main\_covid\_19.covid\_news\_handling module
--------------------------------------------

.. automodule:: main_covid_19.covid_news_handling
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: main_covid_19
   :members:
   :undoc-members:
   :show-inheritance:
