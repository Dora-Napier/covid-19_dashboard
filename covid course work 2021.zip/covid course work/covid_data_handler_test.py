"""module to test functions from covid_data_handler """
from main_covid_19.covid_data_handler import parse_csv_data, process_covid_csv_data
from main_covid_19.covid_data_handler import covid_API_request


def test_parse_csv_data ():
    """test the function test_parse_csv_data works as intended"""
    data = parse_csv_data ('nation_2021-10-28.csv')
    assert len( data ) == 639

def test_process_covid_csv_data ():
    """test the function test_process_covid_csv_data works as intended"""
    current_hospital_cases ,last7days_cases,total_deaths =process_covid_csv_data \
        ( parse_csv_data ('nation_2021-10-28.csv' ) )
    assert current_hospital_cases == 7_019
    assert last7days_cases == 240_299
    assert total_deaths == 141_544
    
def test_covid_API_request():
    """test the function test_covid_API_request works as intended"""
    data = covid_API_request()
    assert isinstance(data, dict)