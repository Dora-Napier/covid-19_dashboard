"""modual that gets, updates and deleats news articles """
import json 
import requests 
import sched, time
from datetime import datetime
import logging

logging.basicConfig(filename='app.log', level=logging.DEBUG)
                            
# opens config.json and reads contene to jf 
with open("config.json", "r") as f:
    json_file = json.load(f)

file = json_file["config"]

deleted_articles= []
url =file['url']
api= file['api']
# establishing news schedular 
news_scheduler = sched.scheduler(time.time, time.sleep)

# function to get news articles with certian words in 
def news_API_request(covid_terms=['covid', 'COVID-19', 'coronavirus']):
    """returns news articles with specified words in them.
    :parameter covid_terms: defaults to a list of covid', 'COVID-19 and 'coronavirus'
    :return:list of news articles.
    """
    paramaters= {'q': covid_terms, 'country': 'gb', 'apiKey':api}
    covid_news = requests.get(url,params=paramaters).json()
    return(covid_news['articles'])

# function to update the displayed news articles 
def update_news(news=news_API_request()):
    """updates and displayes news articles and prevents deleated ones form reappearing.
    :parameter news: defaults to the function news_API_request
    :return:none 
    """
    logging.info('updateded article'+datetime.now().strftime('%H:%M'))
    news_articles.clear() 
    counter=0
    index=0
    for i in news: 
        index= index+1
        while  counter<index:
            # if news aretical deleated dont display it again 
            if news[counter]['title'] in deleted_articles:
                counter= counter +1 
            elif counter>index:
                break
            # add new news article 
            else:
                news_articles.append({'title':news[counter]['title'],
                'content':news[counter]['description']})  
                counter=counter+1 
        # else:

    

# function to delete articles    
def delete_article(title):
    """deletes articles adds them to a list of deleted articles.
    :parameter title: variable 
    :return:none
    """
    deleted_articles.append(title)
    update_news()
    logging.info('deleted article'+datetime.now().strftime('%H:%M'))


news_articles=[{
    'title':'', 
    'content':''
}]