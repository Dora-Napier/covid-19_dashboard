"""module that can get, update and modify covid data as well as schedual updates """
from uk_covid19 import Cov19API
import sched
import time
from .covid_news_handling import update_news, news_scheduler
import logging
from datetime import datetime
import json

logging.basicConfig(filename='app.log', level=logging.DEBUG)

with open("config.json", "r") as f:
    json_file = json.load(f)

file = json_file["config"]
local_location=file['local_location']
location_t= file['location_type']
# establishing data schedular
data_scheduler = sched.scheduler(time.time, time.sleep)
queue_update=[]

# function to calculate the number of infections over 7 days
def infection_update(data_level):
    """calculate the number of infections over 7 days.
    :param data_level: string
    :return: number of infection in 7 days as an integer."""
    x=0 
    infection_7=0
    while data_level['data'][x]['new_cases'] is None :
        x= x+1
    for i in range(x+1,x+8):
        infection_7= infection_7 + data_level['data'][i]['new_cases']
    return(int(infection_7))

# function to update covid data 
def update_covid_data():
    """updates covid data. 
    :return: national and local infections over 7 days, 
    total deaths, area name, nation name and hospital data.
    """

    e_data= covid_API_request(local_location, location_t)
    en_data= covid_API_request('england','nation')

    area_name= e_data['data'][0]['name']
    nation_name= en_data['data'][0]['name']
    hospital_data = en_data['data'][0]['hospital_cases']
    # calculates total deaths 
    i=0
    while en_data['data'][i]['cum_deaths']== None :
        i= i+1
    total_deaths= en_data['data'][i]['cum_deaths']
    #calling function to calcluate 7 day infection rate
    national_infection_7=0
    national_infection_7=infection_update(en_data)
    local_infection_7=0
    local_infection_7=infection_update(e_data)
    logging.info('updated covid data'+ datetime.now().strftime('%H:%M'))
    return(national_infection_7, local_infection_7, 
    total_deaths, area_name, nation_name, hospital_data)

# function to return a list of strings for the rows in a file
def parse_csv_data(csv_filename):
    """return a list of strings for the rows in a file
    :parameter csvfilename: arg1 - csv file 
    :return: a list of the rows from csv_filename.
    """
    rows = []
    with open(csv_filename, newline='') as f_rows:
        reader = f_rows.readlines()
        for i in reader:
            rows.append(i.strip())
        return(rows)

# function to return  the cases in the last 7 days,
#  current hospital cases and the cumulative deaths from the csv data
def process_covid_csv_data(covid_csv_data):
    """ return the cases in the last 7 days,
    current hospital cases and the cumulative deaths from the csv data
    :parameter covid_csv_data: 
    :return: hospital cases, cases over 7 days and total deaths all as
    integers.
    """
    # getting most recent hospital case data
    del covid_csv_data[0]
    count_h=0
    while covid_csv_data[count_h].split(',')[5]== ''  :
        count_h= count_h+1
    hospital_cases_csv= covid_csv_data[count_h].split(',')[5]
    # getting most recent cummlative death data
    count_d=0
    while covid_csv_data[count_d].split(',')[4]== '' :
        count_d= count_d+1
    cum_deaths_csv= covid_csv_data[count_d].split(',')[4]
    # calculating cases over 7 days with most recent data 
    count_c=0
    cases_7_csv=0
    while covid_csv_data[count_c].split(',')[6]== '' :
        count_c= count_c+1
    for i in range (count_c+1, count_c+8):
        cases_7_csv= cases_7_csv+int(covid_csv_data[i].split(',')[6])
    return (int(hospital_cases_csv), int(cases_7_csv),int(cum_deaths_csv))

# function to get the relevent data from the covid API 
def covid_API_request(location= local_location,location_type= location_t):
    """ gets the relevent data from the covid API 
    :parameter location: specifc location defaults to exeter
    :parameter location_type: location used by API defaults to ltla
    :return: covid data 
    """
    cases_and_deaths = {'code': 'areaCode',
         'name': 'areaName',
          'type': 'areaType',
           'date': 'date',
            'cum_deaths': 'cumDailyNsoDeathsByDeathDate',
             'hospital_cases': 'hospitalCases',
              'new_cases': 'newCasesBySpecimenDate'}
    api_filter = [f'areaType={location_type}', f'areaName={location}']
    api_request = Cov19API(filters=api_filter, structure=cases_and_deaths)
    covid_data= api_request.get_json() 
    return(covid_data)

# function to schedual times the news or data is updated 
def schedule_covid_updates(update_interval, update_name, update_type=None):
    """ schedual times the news or data is updated 
    :parameter update_interval: time form now to schedualed update  
    :parameter update_name: what the user called to update 
    :parameter update_type:news or data or both
    """
    # if covid news update selected
    if update_type == 'news':
        logging.info('news updated'+ datetime.now().strftime('%H:%M'))
        event={
        'title':update_name,
        'type':update_type,
        'ID':None 
        }
        event['ID']= news_scheduler.enter(update_interval,1,update_news)
        queue_update.append(event)
        # if repeat != None:
        #     logging.info('news update scheduled to repeat'+ datetime.now().strftime('%H:%M'))
        #     event['ID']= news_scheduler.enter(update_interval+86400,1,update_news, repeat)
        #     queue_update.append(event)


    # if covid data update selected
    elif update_type== 'data':
        logging.info('data updated'+ datetime.now().strftime('%H:%M'))
        event={
            'title':update_name,
            'type':update_type,
            'ID':None
        }
        event['ID']= data_scheduler.enter(update_interval,1,update_covid_data)
        queue_update.append(event)
        # if repeat ==True :
        #     logging.info('data update scheduled to repeat'+ datetime.now().strftime('%H:%M'))
        #     event['ID']= data_scheduler.enter((update_interval+86400),1,update_news, True)
        #     queue_update.append(event)
        
    elif update_type== 'both':
        logging.info('both updated'+ datetime.now().strftime('%H:%M'))
        event={
            'title':update_name,
            'type':update_type,
            'ID':None
        }
        event['ID']= data_scheduler.enter(update_interval,1,update_covid_data)
        queue_update.append(event)
        event['ID']= news_scheduler.enter(update_interval,1,update_covid_data)
        event['title']= ('temp'+update_name)
        queue_update.append(event)
        # if repeat!= None:
        #     logging.info('both updates scheduled to repeat'+ datetime.now().strftime('%H:%M'))
        #     event['ID']= news_scheduler.enter((update_interval+86400),2,update_news, repeat)
        #     queue_update.append(event)
        #     event['ID']= news_scheduler.enter((update_interval+86400),2,update_covid_data)
        #     queue_update.append(event)
        #     event['title']= f'temp{update_name}'