"""main modual that runs the dash bored aswell as handels the scheduled updates """
from typing import Counter
from flask import Flask, render_template, request
from .covid_data_handler import data_scheduler, update_covid_data, schedule_covid_updates, queue_update
from datetime import datetime
from .covid_news_handling import news_articles, update_news, news_scheduler, delete_article
import logging
from os import path, getcwd

logging.basicConfig(filename='app.log', level=logging.DEBUG)


app = Flask(__name__, template_folder=path.join(getcwd(), 'templates'))
update_display=[]

def delete_update(title):
    """deleates scheduled updates made by the user.
    :parameter title:variable
    :return:none
    """
    for i in range (0,len(queue_update)):
        if i['title']== title:
            if i['type']== 'news':
                news_scheduler.cancel(i['ID']) 
            elif i['type']== 'data':
                data_scheduler.cancel(i['ID'])
            elif i['type']== 'both':
                data_scheduler.cancel(i['ID'])
                title='temp'+title
                for j in queue_update:
                    if i['title']== title:
                        news_scheduler.cancel(i['ID'])

    for count in range (0, len(update_display)):
        if update_display[count]["title"] == title or update_display[count]["title"] == 'temp'+title :
            del update_display[count]

    logging.info('deleted update'+datetime.now().strftime('%H:%M'))

# funtion that alows the user to schedule updates for news or data
def user_update(text_box,repeat,update_time,news,covid_data ):
    """alows the user to schedule updates for news or data
    :parameter text_box:contence of the 
    :parameter update_time: update time in the firmat xx:xx
    :parameter news:if update news was selected
    :parameter covid_data:if update covid data was selected
    :return:none
    """
    # if news update selected
    if news != None and covid_data != None:
        display_update(text_box,'news and data update at ',update_time) 
        schedule_covid_updates(delay_calc(update_time),text_box,'both')
        logging.info('schedual update set'+datetime.now().strftime('%H:%M'))
        
    elif news!= None:
        display_update(text_box,'news update at ',update_time) 
        schedule_covid_updates(delay_calc(update_time),text_box,'news')
        logging.info('schedual update set')
    # if covid data update selected
    elif covid_data!=None:
        display_update(text_box,'covid data update at ',update_time )
        schedule_covid_updates(delay_calc(update_time),text_box,'data')
        logging.info('schedual update set')
    

# function to calculate when to preform the scheduled updates    
def delay_calc(sched_time):
    """ calculates when to perform scheduled updates
    :parameter sched_time: user input time in the format xx:xx
    :return delay: delay in seconds
    """
    now= datetime.now()
    now= now.strftime('%H:%M')
    current_h,current_m =now.split(':')
    sched_h,sched_m=sched_time.split(':')
    sched_h, sched_m, current_h, current_m=int(sched_h),int(sched_m), int(current_h), int(current_m)
    #conversion to total seconds
    if now<sched_time:
        delay_h_s= abs((sched_h - current_h) *60 *60)
        delay_m_s= abs((sched_m - current_m) *60)
        delay= delay_h_s + delay_m_s
        logging.info('delay calculated'+datetime.now().strftime('%H:%M'))
    else:
        delay_h_s= abs((current_h - sched_h) *60 *60)
        delay_m_s= abs((current_m - sched_m) *60)
        delay= delay_h_s + delay_m_s

    return(delay)

# function that displays the updates the user has requested 
def display_update(name_update,type_update,time_update):
    """alows the user to schedule updates for news or data
    :parameter name_update: chosen by user input into the text box
    :parameter type_update: news data or both
    :parameter time_update: schedualed time for update 
    :return:none
    """
    update_display.append({
        'title':name_update,
        'content':type_update+time_update})

# function that retrives uptodate covid data 
def refresh_data():
    """retives covid data from other modules """
    global area_name
    global nation_name
    global hospital_data
    global total_deaths
    global local_infection_7
    global national_infection_7

    national_infection_7, local_infection_7, total_deaths,\
         area_name, nation_name, hospital_data= update_covid_data()

@app.route('/')
@app.route('/index')

def home():
    """runs the dashbord 
    :return:none
    """
    #Run Schedulers
    data_scheduler.run(blocking=False)
    news_scheduler.run(blocking=False)

    #Get Values
    text_box= request.args.get('two')
    repeat= request.args.get('repeat')
    update_time= request.args.get('update')
    covid_data= request.args.get('covid-data')
    news= request.args.get('news')
    del_updates=request.args.get('update_item')
    del_articles= request.args.get('notif')

    #If delete artical request submitted
    if del_articles != None:
        delete_article(del_articles)
        
    #If delete update request submitted
    if del_updates != None:
        delete_update(del_updates)
        

    #If update request submitted
    if text_box != None:
        user_update(text_box,repeat,update_time,news,covid_data)

    #Return all values
    return render_template('index.html',
    location=area_name,
    nation_location=nation_name,
    hospital_cases=hospital_data ,
    news_articles=news_articles,
    updates=update_display,
    deaths_total=total_deaths, 
    local_7day_infections=local_infection_7,
    national_7day_infections=national_infection_7 )



if __name__ == '__main__':
    update_news()
    refresh_data()
    app.run()